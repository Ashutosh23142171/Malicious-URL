#Library
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import tldextract
from urllib.parse import urlparse
import re
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from urllib.parse import urlparse, unquote
import pickle
from plotly import graph_objects as go
from wordcloud import WordCloud

import keras#3.12.0
from keras.models import Sequential
from keras import layers
from keras.optimizers import RMSprop
from keras.preprocessing.text import Tokenizer
#from keras.preprocessing.sequence import pad_sequences
from keras.utils import pad_sequences
from keras import regularizers
from keras.models import load_model

# 1 fo display figure
FigFlg=0

def length_Count(url):
    # Remove common prefixes
    prefixes = ['http://', 'https://']
    for prefix in prefixes:
        if url.startswith(prefix):
            url = url[len(prefix):]

    # Remove 'www.' if present
    url = url.replace('www.', '')

    # Return the length of the remaining URL
    return len(url)

def Find_Primary_Domain(url):
    try:
        res = get_tld(url, as_object = True, fail_silently=False,fix_protocol=True)
        pri_domain= res.parsed_url.netloc
    except :
        pri_domain= None
    return pri_domain


# Find Domain
def Find_Domain(url):
    extracted = tldextract.extract(url)
    return f"{extracted.domain}.{extracted.suffix}"

Spl_Char = ['@', '?', '-', '=', '.', '#', '%', '+', '$', '!', '*', ',', '//']


def Char_Count(url, character):
    return url.count(character)


# Function to detect if there's a match between URL and host
def URL_Abnormal(url):
    hostname = urlparse(url).hostname
    hostname = str(hostname)
    match = re.search(hostname, url)
    if match:
        return 1
    else:
        return 0

def HTTP_Flag(url):
    return int("https" in url)

def Digit_Count(string):
    return sum(1 for char in string if char.isdigit())

def Letter_Count(string):
    return sum(1 for char in string if char.isalpha())

Shorten_URL_Type = r'bit\.ly|goo\.gl|shorte\.st|go2l\.ink|x\.co|ow\.ly|t\.co|tinyurl|tr\.im|is\.gd|cli\.gs|' \
                     r'yfrog\.com|migre\.me|ff\.im|tiny\.cc|url4\.eu|twit\.ac|su\.pr|twurl\.nl|snipurl\.com|' \
                     r'short\.to|BudURL\.com|ping\.fm|post\.ly|Just\.as|bkite\.com|snipr\.com|fic\.kr|loopt\.us|' \
                     r'doiop\.com|short\.ie|kl\.am|wp\.me|rubyurl\.com|om\.ly|to\.ly|bit\.do|t\.co|lnkd\.in|' \
                     r'db\.tt|qr\.ae|adf\.ly|goo\.gl|bitly\.com|cur\.lv|tinyurl\.com|ow\.ly|bit\.ly|ity\.im|' \
                     r'q\.gs|is\.gd|po\.st|bc\.vc|twitthis\.com|u\.to|j\.mp|buzurl\.com|cutt\.us|u\.bb|yourls\.org|' \
                     r'x\.co|prettylinkpro\.com|scrnch\.me|filoops\.info|vzturl\.com|qr\.net|1url\.com|tweez\.me|v\.gd|' \
                     r'tr\.im|link\.zip\.net'


def Shorten_URL_Flag(url):
    return int(re.search(Shorten_URL_Type, url, flags=re.I) is not None)

IP_Format = (
    r'(([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.'
    r'([01]?\d\d?|2[0-4]\d|25[0-5])\/)|'
    r'(([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.([01]?\d\d?|2[0-4]\d|25[0-5])\.'
    r'([01]?\d\d?|2[0-4]\d|25[0-5])\/)|'
    r'((0x[0-9a-fA-F]{1,2})\.(0x[0-9a-fA-F]{1,2})\.(0x[0-9a-fA-F]{1,2})\.(0x[0-9a-fA-F]{1,2})\/)'
    r'(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}|'
    r'([0-9]+(?:\.[0-9]+){3}:[0-9]+)|'
    r'((?:(?:\d|[01]?\d\d|2[0-4]\d|25[0-5])\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d|\d)(?:\/\d{1,2})?)'
)

def IP_Add_Flag(url):
    return int(re.search(IP_Format, url, flags=re.I) is not None)

def Malcious_Char_code_Flag(url):
    if re.search(r'javascript:', url):
        return 1
    
    if re.search(r'<\s*script', url, re.IGNORECASE) or re.search(r'on\w*=', url, re.IGNORECASE):
        return 1
    
    return 0

def Text_Encoding_flag(url):
    parsed_url = urlparse(url)
    text_part = parsed_url.path
    decoded_text = unquote(text_part)
    if decoded_text == text_part:
        return 0  # No encoding found
    else:
        return 1  # Encoding found

######################### MAIN CODE ###########################
  
# Define the file path
File_Name = 'malicious_phish.csv'
# read file
data = pd.read_csv(File_Name)
#select n samples
data=data[:1000]
data.isnull().sum()

if FigFlg==1:
    Class_Count = data['type'].value_counts()
    plt.figure(figsize=(6, 6))
    plt.pie(Class_Count, labels=Class_Count.index, autopct='%1.1f%%', colors=sns.color_palette("pastel"))
    plt.title('Malcious Classes of Urls')
    plt.show()

if FigFlg==1:
    Class_Count = data['type'].value_counts()
    colors = [
        '#FF6633', '#FFB399', '#FF33FF', '#FFFF99', '#00B3E6',
        '#E6B333', '#3366E6', '#999966', '#99FF99', '#B34D4D'
    ]
    fig = go.Figure(data=[go.Bar(x=Class_Count.index, y=Class_Count, marker=dict(color=colors))])
    fig.update_layout(
        xaxis_title='Malcious Classes of Urls',
        yaxis_title='Count',
        title='Histogram of URLs',
        plot_bgcolor='black',
        paper_bgcolor='black',
        font=dict(color='white')
    )
    fig.update_xaxes(tickfont=dict(color='white'))
    fig.update_yaxes(tickfont=dict(color='white'))
    fig.show()

if FigFlg==1:
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(' '.join(data['url']))
    plt.figure(figsize=(10, 6))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.title('Word Cloud of URLs')
    plt.show()




data['url'] = data['url'].str.replace('www.', '')
type_to_category = {"benign": 0,"defacement": 1,"phishing": 2,"malware": 3}
data['Category'] = data['type'].map(type_to_category)
data['URL_Length'] = data['url'].apply(len)
if FigFlg==1:
    plt.figure(figsize=(10, 6))
    sns.scatterplot(data=data, x='type', y='URL_Length')
    plt.title("Statistic of URL Length and Type")
    plt.xlabel("Type")
    plt.ylabel("URL Length")
    plt.tight_layout()
    plt.show()

if FigFlg==1:
    plt.figure(figsize=(10, 6))
    sns.barplot(data=data, x='type', y='URL_Length',palette="bright", ci=None)
    plt.title("Statistic of URL Length and Type")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


data['type_ratio'] = data.groupby('type')['URL_Length'].transform(lambda x: x / x.sum() * 100)
data['domain'] = data['url'].apply(Find_Domain)
for character in Spl_Char:
    data[f'{character}'] = data['url'].apply(lambda url: Char_Count(url, character))

data['Digit_Count'] = data['url'].apply(Digit_Count)
data['Letter_Count'] = data['url'].apply(Letter_Count)
data['Abnormal_URL'] = data['url'].apply(URL_Abnormal)
if FigFlg==1:
    sns.set_theme(style="darkgrid")
    sns.countplot(x='Abnormal_URL', data=data, palette="bright")
    plt.xlabel('Abnormal URL')
    plt.ylabel('Count')
    plt.show()

if FigFlg==1:
    # Create a crosstab and plot the bar chart
    pd.crosstab(data["Abnormal_URL"], data["type"]).plot(kind="bar",figsize=(12,5),color=['#003f5c','#ffa600','#bc5090','#ff6361'])
    plt.title('Distribution based on Abnormal_URL and type')
    plt.xlabel('Abnormal_URL')
    plt.xticks(rotation=0)
    plt.ylabel('Frequency')
    plt.legend(title="type")
    plt.show()

data['HTTPS'] = data['url'].apply(HTTP_Flag)

if FigFlg==1:
    # Create a bar plot using Seaborn
    plt.figure(figsize=(10, 6))
    sns.countplot(data=data, x='type', hue='HTTPS',palette="bright")
    plt.title("Statistic of URL Class and HTTPS")
    plt.xlabel("Type")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.legend(title="HTTPS")
    plt.tight_layout()
    plt.show()


# Add a new 'Has_Shortening_Service' column with 1 if it has a shortening service, 0 otherwise
data['Has_Shortening_Service'] = data['url'].apply(Shorten_URL_Flag)

# Add a new 'Has_IP_Address' column with 1 if it has an IP address, 0 otherwise
data['IP_Address'] = data['url'].apply(IP_Add_Flag)
if FigFlg==1:
    # Create a bar plot using Seaborn
    plt.figure(figsize=(10, 6))
    sns.countplot(data=data, x='type', hue='IP_Address',palette='bright')
    plt.title("Statistic of URL Class and IP_Address")
    plt.xlabel("Type")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.legend(title="IP Address")
    plt.tight_layout()
    plt.show()

# Add a new 'Has_Malicious_Code' column with 1 if it has malicious code, 0 otherwise
data['Has_javascript_Code'] = data['url'].apply(Malcious_Char_code_Flag)

# Apply the function to the 'url' column and create a new column 'Has_Text_Encoding'
data['Has_Text_Encoding'] = data['url'].apply(Text_Encoding_flag)


data.isnull().sum()

########################################

X = data.drop(['url','type','Category','domain','type_ratio','*'],axis=1)#,'type_code'
y = data['Category']

print(np.shape(X),np.shape(y))

X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=0)

max_words = 2000
max_len = 400

model1 = Sequential()

model1.add(layers.Embedding(max_words, 40))
model1.add(layers.LSTM(40,dropout=0.5))
model1.add(layers.Dense(1,activation='sigmoid'))
 
model1.compile(optimizer='rmsprop',loss='binary_crossentropy', metrics=['accuracy'])
history = model1.fit(X_train, y_train, epochs=10,validation_data=(X_test, y_test))


# load model
model1 = load_model('model.h5')
# summarize model.
model1.summary()

## Performance 
resultsTest = model1.evaluate(X_train, y_train)
print("RESULT ACCURACY = ", resultsTest)


# Predict probabilities for the test set
y_pred = model1.predict(X_test)
y_pred=y_pred.astype(int)
y_pred=np.ravel(y_pred)
for ik in range(len(y_pred)):
    if y_pred[ik]>=1:
        y_pred[ik]=1
    else:
        y_pred[ik]=0
            
y_test=y_test.astype(int)
y_test=np.ravel(y_test)
for ik in range(len(y_test)):
    if y_test[ik]>=1:
        y_test[ik]=1
    else:
        y_test[ik]=0               

y_pred=np.ravel(y_pred)
y_test=np.ravel(y_test)

print(np.shape(y_pred),np.shape(y_test))

# Classification report
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Compute AUC
auc = roc_auc_score(y_test, y_pred)
print("AUC:", auc)

# Compute ROC curve
fpr, tpr, thresholds = roc_curve(y_test, y_pred)

# Compute FPR and FNR
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
fpr_score = fp / (fp + tn)
fnr_score = fn / (fn + tp)

print("False Positive Rate (FPR):", fpr_score)
print("False Negative Rate (FNR):", fnr_score)

precision, recall, fscore, support =precision_recall_fscore_support(y_test, y_pred, average='macro')
print('Avg. precision: {}'.format(precision))
print('Avg. recall: {}'.format(recall))
print('Avg. fscore: {}'.format(fscore))

